const canvas = document.getElementById("drawBoard");
const ctx = canvas.getContext("2d");

const shapeDropdown = document.getElementById("select-contour");
const pointSlider = document.getElementById("select-points");

const uiPlayerPoints = document.getElementById("player_points");
const uiPcPoints = document.getElementById("pc_points");
const uiIntersectPreview = document.getElementById("about_to_intersect");

const COLOR_POINT = "#000000"
const COLOR_LINE = "#000000"
const COLOR_FRIEDNLY = "#00ff00"
const COLOR_OPPONENT = "#ff6666ff"
const COLOR_SELECTED = "#bb1be3ff"
const COLOR_INTERSECT = "#9c0000ff"

let pointSize = 10;
let selectPointSize = 15;
let lineWidth = 2;
let mouseMargin = 20;

let idCounter = 1;

let pointCount = pointSlider.value; // Nomaina ar UI


const arena_x = 400;
const arena_y = 400;


const canvasW = canvas.width
const canvasH = canvas.height
const centerX = canvasW/2
const centerY = canvasH/2


let selectedShape = shapeDropdown.value // Nomaina ar UI
let selectedAlg = "minimax" // Nomaina ar UI



let isPlayerTurn = false;
let playerPoints = 0;
let pcPoints = 0;

let lines = [] // Līnijas, [sākuma punkts, beigu punkts, id], punkti doti pēc indeksa
let filledPoints = [] // masīvs, satur visus punktus un viņu id, pēc id nosaka vai pašreizējā spēlētāja vai nē 
let drawPoints = [] // masīvs, satur visus punktus un viņu pozīcijas
let highlightedPoint = undefined
let fromDrawPoint = undefined
let mousePos = {x: 0, y:0}

document.addEventListener("mousemove", (e)=>{
    const rect = canvas.getBoundingClientRect();
    mousePos = {x: e.clientX - rect.left, y:e.clientY - rect.top}

    let minX = mouseMargin*2
    let minY = mouseMargin*2
    let selPoint = undefined
    for (let i = 0; i < drawPoints.length; i++) {
        const el = drawPoints[i];
        let pX = mousePos.x -el[0]
        let pY = mousePos.y -el[1]
        if(Math.hypot(pX**2 + pY**2)< Math.hypot(minX**2, minY**2) && filledPoints[i] == 0 && i != fromDrawPoint){
            selPoint = i
            minX = pX
            minY = pY
        }
    }
    highlightedPoint = selPoint

})
document.addEventListener("mousedown", (e)=>{
    fromDrawPoint = highlightedPoint
    highlightedPoint = undefined
})
document.addEventListener("mouseup", (e)=>{
    if(fromDrawPoint != highlightedPoint && fromDrawPoint != undefined && highlightedPoint != undefined){
        makeAMove(fromDrawPoint, highlightedPoint)
    }
    fromDrawPoint = undefined
    highlightedPoint = undefined
})

let graph = {}





shapeDropdown.addEventListener("input", (e) => {
    selectedShape = e.target.value
    console.log(selectedShape)
    initGame()
})
pointSlider.addEventListener("input", (e) => {
    pointCount = Number(e.target.value)
    console.log(pointCount)
    initGame()
})

function line2id(line){
    return line[2]
}

function updScore(){
    uiPlayerPoints.textContent = playerPoints
    uiPcPoints.textContent = pcPoints
}

function updIntersectCount(count){
    uiIntersectPreview.textContent = count
}

function addFunctionalLine(from, to){
    if(isPlayerTurn) p1Lines.add(idCounter)
    else p2Lines.add(idCounter)
    lines.push([from, to, idCounter])
    filledPoints[from] = idCounter
    filledPoints[to] = idCounter
    idCounter++
}

function calculateGameTree(){

}


let p1Lines = new Set([0])
let p2Lines = new Set([0])
function friendlyLine(id){
    if(isPlayerTurn) return p1Lines.has(id)
    else return p2Lines.has(id)
}

function calculateIntersections(from, to){
    let intersections = []
    function isInside(point, start, end){
        if(start > end)
            return point > start || point < end
        else
            return point > start && point < end
    }
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        if(!friendlyLine(line2id(line)) && (
            (isInside(line[0], from, to) && !isInside(line[1], from, to)) ||
            (isInside(line[1], from, to) && !isInside(line[0], from, to))
        )
        ){
            intersections.push(line)
        }
    }
    return intersections
}

function initGame(){
    p1Lines = new Set([0])
    p2Lines = new Set([0])
    lines = []
    filledPoints = []
    drawPoints = []
    fromDrawPoint = undefined
    highlightedPoint = undefined
    playerPoints = 0
    pcPoints = 0

    for (let i = 0; i < pointCount; i++) {
        filledPoints.push(0) // Todo
    }

    const arena_x_2 = arena_x / 2
    const arena_y_2 = arena_y / 2
    switch(selectedShape){
        case "square":
            {
                let lSpace = 2*(arena_x + arena_y) / pointCount
                for (let i = 0; i < pointCount; i++) {
                    offset = i*lSpace
                    if(offset < arena_x){
                        drawPoints.push([centerX+offset - arena_x_2, centerY+arena_y_2])
                    }
                    else if (offset < arena_x+arena_y){
                        offset = offset - arena_x
                        drawPoints.push([centerX+arena_x_2, centerY+arena_y_2 - offset])
                    }
                    else if (offset < 2*arena_x+arena_y){
                        offset = offset - arena_x-arena_y
                        drawPoints.push([centerX+arena_x_2 - offset, centerY+-arena_y_2])
                    }
                    else{
                        offset = offset - 2*arena_x-arena_y
                        drawPoints.push([centerX-arena_x_2, centerY+offset-arena_y_2])
                    }
                }
            }
            break
        case "circle":
            {
                for (let i = 0; i < pointCount; i++) {
                    let deg = (i / pointCount)* Math.PI * 2
                    drawPoints.push([centerX+arena_x_2*Math.cos(deg), centerY+arena_y_2*Math.sin(deg)])
                }
            }
            break
        case "triangle":
            {
                let hypot = Math.sqrt((arena_x_2)**2 + arena_y**2)
                let lSpace = (arena_x + 2*hypot ) / pointCount
                let rat = arena_x_2 / arena_y
                for (let i = 0; i < pointCount; i++) {
                    offset = i*lSpace
                    if(offset < arena_x){
                        drawPoints.push([centerX+offset - arena_x_2, centerY+arena_y_2])
                    }
                    else if (offset < arena_x+hypot){
                        offset -= arena_x
                        let cY = offset / Math.sqrt(rat**2 + 1)
                        drawPoints.push([centerX+arena_x_2-cY*rat, centerY+arena_y_2 - cY])
                    }
                    else{
                        offset -= arena_x+hypot
                        let cY = offset / Math.sqrt(rat**2 + 1)
                        drawPoints.push([centerX-cY*rat, centerY-arena_y_2+cY])
                    }
                }
            }
            break
            
    }

    
    updScore()

    isPlayerTurn = Math.random() > 0.5
    if(!isPlayerTurn){
        chooseNextTurn()
    }
}

function drawPoint(pos_x, pos_y, color){
    ctx.beginPath();
    ctx.fillStyle = color;
    ctx.arc(pos_x, pos_y, pointSize, 0, 2 * Math.PI);
    ctx.fill();
}
function drawLine(fromX, fromY, toX, toY, col, dashed=[]){
    ctx.beginPath();
    ctx.strokeStyle = col;
    ctx.lineWidth = lineWidth;
    ctx.setLineDash(dashed);
    ctx.moveTo(fromX, fromY);
    ctx.lineTo(toX, toY);
    ctx.stroke();
    ctx.setLineDash([]);
}
function drawHighlight(x,y){
    ctx.beginPath();
    ctx.strokeStyle = COLOR_SELECTED;
    ctx.setLineDash([10, 10]);
    ctx.lineWidth = lineWidth;
    ctx.arc(x, y, selectPointSize, 0, 2 * Math.PI);
    ctx.stroke();
    ctx.setLineDash([]);
}
function drawFrom(x,y){
    ctx.beginPath();
    ctx.strokeStyle = COLOR_FRIEDNLY;
    ctx.lineWidth = lineWidth;
    ctx.arc(x, y, selectPointSize, 0, 2 * Math.PI);
    ctx.stroke();
}

function drawLoop(){
    ctx.clearRect(0, 0, canvasW, canvasH);

    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        const from = drawPoints[line[0]]
        const to = drawPoints[line[1]]
        const drawCol = friendlyLine(line2id(line)) ? COLOR_FRIEDNLY : COLOR_OPPONENT
        drawLine(from[0], from[1], to[0], to[1], drawCol)
    }

    if(fromDrawPoint != undefined && highlightedPoint != undefined) {
        let point = drawPoints[fromDrawPoint]
        let hPoint = drawPoints[highlightedPoint]
        drawLine(point[0], point[1], hPoint[0], hPoint[1], COLOR_FRIEDNLY, [10,10])
        const intersects = calculateIntersections(fromDrawPoint, highlightedPoint)
        for (let i = 0; i < intersects.length; i++) {
            const intersect = intersects[i];
            const i_f_p = drawPoints[intersect[0]]
            const i_t_p = drawPoints[intersect[1]]
            drawLine(i_f_p[0], i_f_p[1], i_t_p[0], i_t_p[1], COLOR_INTERSECT)
        }
        updIntersectCount(intersects.length)
    }
    else updIntersectCount(0)

    for (let i = 0; i < drawPoints.length; i++) {
        const coords = drawPoints[i];
        drawPoint(coords[0], coords[1],COLOR_POINT)
    }

    drawPoint(mousePos.x, mousePos.y, COLOR_SELECTED)

    
    if(fromDrawPoint != undefined) {
        let point = drawPoints[fromDrawPoint]
        drawFrom(point[0], point[1])
    }
    if(highlightedPoint != undefined) {
        let point = drawPoints[highlightedPoint]
        drawHighlight(point[0], point[1])
    }
    requestAnimationFrame(drawLoop)
}

function hasValidMoves(){
    let empty = 0
    for (let i = 0; i < filledPoints.length; i++) {
        if(!filledPoints[i]) empty++
    }
    return empty >= 2
}

function showResults(){
    console.log(`P1 points: ${playerPoints}; P2 points: ${pcPoints}`)
    // TODO
    initGame()
}

function chooseNextTurn(){
    // TODO

    calculateGameTree() // TODO
    let start = undefined
    while(true){
        start = Math.floor(Math.random()*pointCount)
        if(!filledPoints[start]) break
    }
    let end = undefined
    while(true){
        end = Math.floor(Math.random()*pointCount)
        if(!filledPoints[end] && end != start) break
    }
    console.log(`Choosing ${start} ${end}`)
    makeAMove(start, end)

}

function makeAMove(from, to){
    if(filledPoints[from] || filledPoints[to]) return
    let intersects = calculateIntersections(from, to).length
    addFunctionalLine(from, to)
    if(isPlayerTurn) pcPoints += intersects
    else playerPoints += intersects 

    onNextTurn()
}

function onNextTurn(){
    updScore()
    if(!hasValidMoves())
    {
        showResults()
        return
    }
    isPlayerTurn = !isPlayerTurn
    if(!isPlayerTurn){
        chooseNextTurn()
    }
    // TODO main user loop
}

// Karoce!!!!!!!!!!!!!!!
// Good luck, have fun
// Kurs grib taisit UI, kurs algoritmus? (+ kurs JS loopu prieks liniju vilksanas + whatever)




drawLoop() // Init draw
initGame() // TODO: sakuma izveles ekrans